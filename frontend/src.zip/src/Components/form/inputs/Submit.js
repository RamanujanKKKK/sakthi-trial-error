const Submit = (props) => {
  return (
    <button className="submit-btn" onClick={props.sendData} x>
      Submit
    </button>
  );
};
export default Submit;
