import { useState, useEffect } from "react";
import '../Styles/TrainingInfo.css';
export const TrainingInfo = (props)=>{

    return <></>

}   