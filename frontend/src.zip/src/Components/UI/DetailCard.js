// import Card from "@mui/joy/Card";
// import CardContent from "@mui/joy/CardContent";
// import CardActions from "@material-ui/core/CardActions";
// import ButtonBase from "@material-ui/core/ButtonBase";
// import Typography from "@mui/joy/Typography";

// const DetailCard = (props) => {
//   return (
//     <Card variant="solid">
//       <ButtonBase
//         className={props.classes.cardAction}
//         onClick={(event) => {
//           props.onClick();
//         }}
//       >
//         <CardContent>
//           <Typography level="title-md" textColor="inherit">
//             {props.deptname}
//           </Typography>
//           <Typography textColor="inherit">{props.deptdesc}</Typography>
//         </CardContent>
//       </ButtonBase>
//     </Card>
//   );
// };

// export default DetailCard;
